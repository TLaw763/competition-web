# @enigmic-co/ui

The shared Enigmic look: theme tokens, the app shell and the filter/sort
template. Enigmic Cards (card-web) is the visual reference; the rules are in
the enigmic-card-platform styling guide (`docs/design-system/styling-guide.md`,
D-064). Every Enigmic web app uses this package instead of copying CSS or
building its own header.

Requires Next.js 15/16, React 19, Tailwind CSS 4 and `lucide-react`.

## Import from the module, not the index

Import each piece from its own module (`@enigmic-co/ui/AppHeader`,
`@enigmic-co/ui/SiteFooter`, `@enigmic-co/ui/filters/FilterDropdown`, ...).
The package index (`@enigmic-co/ui`) still works, but when a server component
imports it, Next.js bundles every client component it re-exports into that
page: in card-web that was 3.3 kB of first-load JS on every page (measured
2026-11-08). The module path is the file name under `src/`, without the
extension.

## Adopting it in an app

1. Vendor the tarball (`scripts/pack-client-packages.sh <app>/vendor`, see
   `docs/client-packages.md`) and add `@enigmic-co/ui` to `package.json`.
2. `app/globals.css`:

   ```css
   @import "tailwindcss";
   @import "tw-animate-css";
   @import "@enigmic-co/ui/styles/theme.css";
   /* list screens: */
   @import "@enigmic-co/ui/styles/filters.css";
   ```

   `theme.css` holds the tokens (light/dark), the Tailwind `@theme` mapping,
   the `dark:` variant and an `@source` for the package's own classes. Don't
   redefine the tokens in the app.
   The backdrop behind a dialog or sheet is `bg-overlay` (`--overlay`,
   since 0.4.2), not `bg-black/50`.

3. `app/layout.tsx`:

   ```tsx
   import { Geist, Geist_Mono } from "next/font/google";
   import { COLOR_MODE_BOOTSTRAP } from "@enigmic-co/ui/color-mode";
   import { PageContainer } from "@enigmic-co/ui/PageContainer";

   const geistSans = Geist({ subsets: ["latin"], variable: "--font-geist-sans" });
   const geistMono = Geist_Mono({ subsets: ["latin"], variable: "--font-geist-mono" });

   <html lang="en" data-color-mode="light" suppressHydrationWarning>
     <head>
       <script dangerouslySetInnerHTML={{ __html: COLOR_MODE_BOOTSTRAP }} />
     </head>
     <body
       className={`${geistSans.variable} ${geistMono.variable} font-sans antialiased`}
     >
       <div className="min-h-screen bg-background">
         <Header /> {/* a client component around AppHeader */}
         <PageContainer>{children}</PageContainer>
         <Footer /> {/* SiteFooter with the app's notice */}
       </div>
     </body>
   </html>;
   ```

4. The header:

   ```tsx
   "use client";
   import { AppHeader } from "@enigmic-co/ui/AppHeader";
   import { Library, Tags, Users } from "lucide-react";

   <AppHeader
     brand={{ href: "/", name: "Enigmic Collector" }}
     nav={[
       { href: "/collection", label: "Collection", icon: Library },
       { href: "/binders", label: "Binders", icon: Tags },
       { href: "/teams", label: "Teams", icon: Users },
     ]}
     account={
       session
         ? {
             status: "signed-in",
             displayName,
             accountHref: "/account",
             links: [],
             onSignOut,
           }
         : { status: "signed-out", signInHref: "/login" }
     }
     phoneMenu
   />;
   ```

   Leave `account` out for an app without accounts (card-web). `title`
   replaces the brand (Competition Tools' chosen event). Apps with many
   links: `menuBelow="lg"` puts everything in the Menu button below that
   breakpoint, and `compactBelow="2xl"` shows icon-only links (label as a
   tooltip and for screen readers) below that one (card-admin).

## Filters and sorting

```tsx
<FilterPanel>
  <FilterToolbar
    label="Filter collection"
    search={<FilterSearch value={q} onChange={setQ} placeholder="Search your cards…" />}
    filters={
      <>
        <FilterSingleSelect label="Rarity" … />
        <FilterDropdown label="Condition" … />
        <FilterRangeControl label="Copies" … />
      </>
    }
    sort={<SortControl options={SORTS} field={sort} direction={dir} onChange={setSort} />}
    activeCount={activeCount}
    onClear={clearAll}
  />
  {results}
</FilterPanel>
```

Keep filter and sort state in the URL and replace (not push) history entries
on change.

## Checks before shipping a screen

Screenshot it next to card-web at 1280px and 390px, light and dark: same
header, account area, content width, footer and toolbar.
